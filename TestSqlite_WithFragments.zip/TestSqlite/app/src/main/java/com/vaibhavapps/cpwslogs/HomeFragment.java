package com.vaibhavapps.cpwslogs;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class HomeFragment extends Fragment {
    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v = inflater.inflate(R.layout.fragment_home, container, false);

        Button Shed_zero, Shed_one, Shed_two, Shed_three, Shed_four;

        Shed_zero = v.findViewById(R.id.shed0);
        Shed_one = v.findViewById(R.id.shed1);
        Shed_two = v.findViewById(R.id.shed2);
        Shed_three = v.findViewById(R.id.shed3);
        Shed_four = v.findViewById(R.id.shed4);

        Shed_zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "0";
                sendListener.sendMessage(message);
            }
        });
        Shed_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "1";
                sendListener.sendMessage(message);
            }
        });
        Shed_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "2";
                sendListener.sendMessage(message);
            }
        });
        Shed_three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "3";
                sendListener.sendMessage(message);
            }
        });
        Shed_four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "4";
                sendListener.sendMessage(message);
            }
        });
        return v;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
        Activity activity = (Activity) context;
        try {
            sendListener = (OnMessageSendListener) context;
        }
        catch (ClassCastException e){
            throw new ClassCastException(activity.toString()
            + "must implement OnMessageSendListner");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    OnMessageSendListener sendListener;
     interface OnMessageSendListener {
        // TODO: Update argument type and name
        void sendMessage(String s);
    }

}
