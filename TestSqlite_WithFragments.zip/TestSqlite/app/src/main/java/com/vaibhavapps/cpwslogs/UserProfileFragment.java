package com.vaibhavapps.cpwslogs;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//
///**
// * A simple {@link Fragment} subclass.
// * Activities that contain this fragment must implement the
// * {@link UserProfileFragment.OnFragmentInteractionListener} interface
// * to handle interaction events.
// * Use the {@link UserProfileFragment#newInstance} factory method to
// * create an instance of this fragment.
// */
public class UserProfileFragment extends Fragment {
    EditText username, password, repeatPassword;
    Button save, cancel;

    public UserProfileFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_user_profile, container, false);
        save = (Button) v.findViewById(R.id.button_saveProfile);
        cancel = (Button) v.findViewById(R.id.button_cancelProfile);
        username = (EditText) v.findViewById(R.id.editText_userName);
        password = (EditText) v.findViewById(R.id.editText_pswd);
        repeatPassword = (EditText) v.findViewById(R.id.editText_pswd1);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uName = username.getText().toString();
                String p1 = password.getText().toString();
                String p2 = repeatPassword.getText().toString();

                if(p1.equals(p2) && !uName.isEmpty()) {
                    Toast.makeText(getActivity(), "Data saved successfully", Toast.LENGTH_SHORT).show();

                    HomeFragment home_fragment = new HomeFragment();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.parentlayout, home_fragment, "Home fragment");
                    ft.commit();
                } else {
                    Toast.makeText(getActivity(), "Please enter password and confirm password same or username should not be empty", Toast.LENGTH_SHORT).show();
                }

            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragment home_fragment = new HomeFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.parentlayout, home_fragment, "Home fragment");
                ft.commit();
            }
        });
        return v;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        /*if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        /*mListener = null;*/
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */

}
