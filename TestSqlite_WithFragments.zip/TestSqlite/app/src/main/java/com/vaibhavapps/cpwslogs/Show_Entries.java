package com.vaibhavapps.cpwslogs;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Show_Entries extends Fragment {
    Button nav;
    ListView show_data;
    ArrayList<LogDataHelper> items;
    StringBuilder builder = new StringBuilder();
    String no;
    List<String> data;


   @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_show__entries, container, false);
        show_data = (ListView) v.findViewById(R.id.showdata);
        nav = (Button) v.findViewById(R.id.nav);


        Bundle buttons;
        buttons = getArguments();

        no = buttons.getString("shed_id");



        getData();
        if (!data.isEmpty()){
            ArrayAdapter<String> aap = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data);
            show_data.setAdapter(aap);
        }else {
            Toast.makeText(getActivity(), "Please enter data to show in the list view ",Toast.LENGTH_SHORT).show();
        }
//        show_data.
       nav.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               HomeFragment home_fragment = new HomeFragment();
               FragmentManager fm = getFragmentManager();
               FragmentTransaction ft = fm.beginTransaction();
               ft.replace(R.id.parentlayout, home_fragment, "Home fragment");
               ft.commit();
           }
       });

        return v;
    }

    public List<String> getData() {
        items = new ArrayList<LogDataHelper>();
        data = new ArrayList<>();
        Bundle shed;
        shed = getArguments();
        String ids = shed.getString("shed_id");
        DBManager dbManager;
        dbManager = new DBManager(getActivity());
        dbManager.open();
        Log.d("IDS", ids);
        items = dbManager.readAllItems(ids);

        for (int i = 0; i < items.size(); i++) {
            Log.d("data", "DATA : " + items.get(i).date);
            Log.d("data", "DATA : " + items.get(i).shed_log);
            builder.append(items.get(i).treatment + items.get(i).date + items.get(i).temperature + items.get(i).humidity + items.get(i).ammonium);
//            Toast.makeText(getContext(), "data is" +builder,Toast.LENGTH_LONG).show();
            data.add(items.get(i).treatment + " " + items.get(i).date + " " + items.get(i).temperature + " " + items.get(i).humidity + " " + items.get(i).ammonium);
        }

        return data;
    }


    /*@Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }
*/


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
}
