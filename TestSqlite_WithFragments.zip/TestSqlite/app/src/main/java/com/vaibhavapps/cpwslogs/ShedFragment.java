package com.vaibhavapps.cpwslogs;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.SimpleTimeZone;

public class ShedFragment extends Fragment {
    TextView t;
    EditText Temperature, humidity, ammonia;
    String temperatures, humid, ammonium;
    Button save_log, show_log, Home, prev, nxt;
    Spinner spn;

    List <String> list;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    OnShedSendIdListener id_listener;
    public interface OnShedSendIdListener{
        void sendId(String id);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.fragment_shed, container, false);
        save_log = v.findViewById(R.id.button_savelogEntry);
        Temperature = v.findViewById(R.id.editText_Temperature);
        humidity = v.findViewById(R.id.editText_Humidity);
        ammonia = v.findViewById(R.id.editText_Ammonia);
        Home = v.findViewById(R.id.button_home);
        show_log = v.findViewById(R.id.button_showlog);
        t = v.findViewById(R.id.textView_shedTitle);
        Bundle b = getArguments();
        final String data_got = b.getString("position");
        t.setText("Shed " + data_got);
        spn = v.findViewById(R.id.spinner_treatType);
        list = new ArrayList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,list);
        spn.setAdapter(adapter);

        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragment frags = new HomeFragment();
                FragmentManager fragmentManager;
                fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction;
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.parentlayout, frags, "Home Fragment");
                fragmentTransaction.commit();

            }
        });
        save_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Temperature.getText().toString().isEmpty() && !humidity.getText().toString().isEmpty() && !ammonia.getText().toString().isEmpty()) {

                    String data = t.getText().toString();
                    String Treatment_choice = spn.getSelectedItem().toString();
                    SimpleDateFormat formatdate = new SimpleDateFormat("dd/MM/yyyy");
                    Date date = new Date();
                    String current_date = formatdate.format(date);
                    temperatures = Temperature.getText().toString();
                    humid = humidity.getText().toString();
                    ammonium = ammonia.getText().toString();

                    Log.d("Current_date", current_date);
                    Log.d("data", data);
                    Log.d("Treatment_choice", Treatment_choice);
                    Log.d("Temperatures", temperatures);
                    Log.d("Humid", humid);
                    Log.d("Ammonium", ammonium);


                    DBManager dbManager;
                    dbManager = new DBManager(getActivity());
                    dbManager.open();
                    dbManager.insert(data, temperatures, humid, ammonium, Treatment_choice, current_date);
                    dbManager.close();
                    Toast.makeText(getActivity(),"Entry saved", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "Entry not saved as all the data not entered, enter all entries and then save", Toast.LENGTH_LONG).show();
                }


            }
        });
        show_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count = t.getText().toString();
                id_listener.sendId(count);
            }
        });
        prev = (Button) v.findViewById(R.id.button_prev);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = Integer.parseInt(data_got);
                while (n != 0) {
                    int m = n - 1;
                    t.setText("Shed " + m);
                }



            }
        });
        nxt = (Button) v.findViewById(R.id.button_next);
        nxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = Integer.parseInt(data_got);
                while (n != 4) {
                    int m = n + 1;
                    t.setText("Shed " + m);
                }

            }
        });
        return v;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity = (Activity) context;
        try {
            id_listener = (ShedFragment.OnShedSendIdListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "must implement onMessageSendListner");
        }
    }
}
