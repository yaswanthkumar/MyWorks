package com.vaibhavapps.cpwslogs;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements HomeFragment.OnMessageSendListener,ShedFragment.OnShedSendIdListener{
    DBManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        HomeFragment home_fragment = new HomeFragment();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.parentlayout, home_fragment, "Home fragment");
        ft.commit();

    }
//    Creating options menu.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

       int option_id = item.getItemId();

        switch(option_id) {
            case R.id.optionSend:
                SendDataEntries();
                return true;
            case R.id.optionSave:
                saveData();
                return true;
            case R.id.optionProfile:
                UserProfileFragment profileFragment = new UserProfileFragment();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.parentlayout, profileFragment, "Profile fragment");
                ft.commit();
                return true;
            default :
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed() { exitByBackKey();}

    public void saveData() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage("Do you wish to save data ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).show();
    }

    public void SendDataEntries(){
        AlertDialog alertDialog;
        alertDialog = new AlertDialog.Builder(this)
                .setMessage("Are you sure? This will delete all the entries.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        Toast.makeText(getApplicationContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                        dbManager = new DBManager(getApplicationContext());
                        dbManager.open();
                        dbManager.delete();
                        dbManager.close();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                }).show();
    }

//                  builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//		@Override
//		public void onClick(DialogInterface dialog, int arg1) {
//			Toast toast = Toast.makeText(context, "You are a HAPPY person.", Toast.LENGTH_LONG);
//			toast.show();
//			dialog.cancel();
//		}
//        })
//	.setNegativeButton("No", new DialogInterface.OnClickListener() {
//		@Override
//		public void onClick(DialogInterface dialog, int arg1) {
//			Toast toast = Toast.makeText(context, "You are a SAD person.", Toast.LENGTH_LONG);
//			toast.show();
//			dialog.cancel();
//		}
//	});


    public void exitByBackKey() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage("Do you wish to save data first ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).show();
    }
    @Override
    public void sendMessage(String position) {
        ShedFragment sf = new ShedFragment();
        Bundle b = new Bundle();
        b.putString("position", position);
        sf.setArguments(b);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.parentlayout, sf, "Shed Fragment");
        fragmentTransaction.commit();
    }

    @Override
    public void sendId(String id) {
        Show_Entries show_entries = new Show_Entries();
        Bundle bundle = new Bundle();
        bundle.putString("shed_id",id);
        show_entries.setArguments(bundle);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.parentlayout, show_entries, "");
        ft.commit();
    }




}




    /*private void addFragment(){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
       HomeFragment homeFragment = new HomeFragment();
        fragmentTransaction.replace(R.id.parentlayout,homeFragment);
        fragmentTransaction.commit();
    }*/