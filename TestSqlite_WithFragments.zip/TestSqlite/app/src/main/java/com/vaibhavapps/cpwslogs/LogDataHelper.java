package com.vaibhavapps.cpwslogs;

public class LogDataHelper {
    public String id;
    public String shed_log;
    public String temperature;
    public String humidity;
    public String ammonium;
    public String treatment;
    public String date;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getShed_log() {
        return shed_log;
    }

    public void setShed_log(String shed_log) {
        this.shed_log = shed_log;
    }



    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getAmmonium() {
        return ammonium;
    }

    public void setAmmonium(String ammonium) {
        this.ammonium = ammonium;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
