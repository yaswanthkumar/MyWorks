package com.vaibhavapps.patiententry;

public class PatientRegisterHelper {

    String id;
    String patient_id;
    String uname;

    String email_pat;
    String mob_pat;
    String gender_pat;
    String age_pat;
    String profession_pat;
    String gender;
    String regArea;
    String dist;
    String state;
    String country;
    String comments;
    String submit_by;
    String submit_by_email;



    //        public void insertToPatient(String pat_id, String pat_name, String pat_email, String pat_mob, String pat_age,
// String pat_prof, String pat_gender, String pat_area, String pat_dist, String pat_state,
// String pat_country, String pat_staff_com, String subm_by, String subm_by_em) {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(String patient_id) {
        this.patient_id = patient_id;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getEmail_pat() {
        return email_pat;
    }

    public void setEmail_pat(String email_pat) {
        this.email_pat = email_pat;
    }

    public String getMob_pat() {
        return mob_pat;
    }

    public void setMob_pat(String mob_pat) {
        this.mob_pat = mob_pat;
    }

    public String getGender_pat() {
        return gender_pat;
    }

    public void setGender_pat(String gender_pat) {
        this.gender_pat = gender_pat;
    }

    public String getAge_pat() {
        return age_pat;
    }

    public void setAge_pat(String age_pat) {
        this.age_pat = age_pat;
    }

    public String getProfession_pat() {
        return profession_pat;
    }

    public void setProfession_pat(String profession_pat) {
        this.profession_pat = profession_pat;
    }

    public String getRegArea() {
        return regArea;
    }

    public void setRegArea(String regArea) {
        this.regArea = regArea;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(String dist) {
        this.dist = dist;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSubmit_by() {
        return submit_by;
    }

    public void setSubmit_by(String submit_by) {
        this.submit_by = submit_by;
    }

    public String getSubmit_by_email() {
        return submit_by_email;
    }

    public void setSubmit_by_email(String submit_by_email) {
        this.submit_by_email = submit_by_email;
    }
}
