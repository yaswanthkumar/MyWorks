package com.vaibhavapps.patiententry;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class DatabaseHelper extends SQLiteOpenHelper  {

    //Table name
    public static final String TABLE_ROLE = "ROLE";
//    public static final String TABLE_USER = "";
//    public static final String TABLE_ADMIN = "";



    //Role Table columns
    public static final String ROW_ID = "_id";
    public static final String ROLE = "role";
    public static final String USER_NAME = "u_name";
    public static final String PASSWORD = "pswd";
    public static final String EMAIL_ID = "email_id";
    public static final String MOB_NO = "mob_no";
    public static final String GENDER = "gender";
    public static final String EMP_ID = "emp_id";
    public static final String AREA = "area";
    public static final String DISTRICT = "district";
    public static final String STATE = "state";
    public static final String COUNTRY = "country";

// patient table name
    public static final String TABLE_PATIENT = "PATIENT";

//    Patient table columns.
    public static final String PAT_ID = "pat_id";
    public static final String PATIENT_ID = "patient_id";
    public static final String PATIENT_NAME = "pat_name";
    public static final String PATIENT_AGE = "pat_age";
    public static final String PATIENT_PROFESSION = "pat_prof";

    public static final String PATIENT_EMAIL_ID = "pat_email_id";
    public static final String PATIENT_MOB_NO = "pat_mob_no";
    public static final String PATIENT_GENDER = "pat_gender";
    public static final String PATIENT_AREA = "pat_area";
    public static final String PATIENT_DISTRICT = "pat_district";
    public static final String PATIENT_STATE = "pat_state";
    public static final String PATIENT_COUNTRY = "pat_country";
    public static final String PATIENT_STAFF_COMM = "pat_staff_comm";
    public static final String SUBMITTED_BY = "submited_by";
    public static final String SUBMITTED_BY_EMAIL = "submited_by_em";
    //Database Information
    static final String DB_NAME = "HOSPITAL.DB";

    //Database version
    static final int DB_VERSION = 1;

    //Role Table query
//    private static final String CREATE_TABLE_ROLE = "create table " + "TABLE_ROLE" + "(" + ROW_ID +
//            " INTEGER PRIMARY KEY AUTOINCREMENT, " + ROLE + " TEXT, " + NAME + " TEXT, " + EMAIL_ID + " TEXT)";

    private static final String CREATE_ROLE_TABLE =
            "CREATE TABLE " + TABLE_ROLE + "("
                    + ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + ROLE + " INTEGER,"
                    + USER_NAME + " TEXT,"
                    + PASSWORD + " TEXT,"
                    + GENDER + " TEXT,"
                    + EMAIL_ID + " TEXT,"
                    + MOB_NO + " INTEGER,"
                    + EMP_ID + " TEXT,"
                    + AREA + " TEXT,"
                    + DISTRICT + " TEXT,"
                    + STATE + " TEXT,"
                    + COUNTRY + " TEXT)";

    private static final String CREATE_PATIENT_TABLE =
            "CREATE TABLE " + TABLE_PATIENT + "("
                    + PAT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + PATIENT_ID + " TEXT,"
                    + PATIENT_NAME + " TEXT,"
                    + PATIENT_EMAIL_ID + " TEXT,"
                    + PATIENT_MOB_NO + " INTEGER,"
                    + PATIENT_AGE + " TEXT,"
                    + PATIENT_PROFESSION + " TEXT,"
                    + PATIENT_GENDER + " TEXT,"
                    + PATIENT_AREA + " TEXT,"
                    + PATIENT_DISTRICT + " TEXT,"
                    + PATIENT_STATE + " TEXT,"
                    + PATIENT_COUNTRY + " TEXT,"
                    + PATIENT_STAFF_COMM + " TEXT,"
                    + SUBMITTED_BY + " TEXT,"
                    + SUBMITTED_BY_EMAIL + " TEXT)";

// public static final String PAT_ID = "pat_id";
//    public static final String PATIENT_ID = "patient_id";
//    public static final String PATIENT_NAME = "pat_name";
//
//    public static final String PATIENT_EMAIL_ID = "pat_email_id";
//    public static final String PATIENT_MOB_NO = "pat_mob_no";
//    public static final String PATIENT_GENDER = "pat_gender";
//    public static final String PATIENT_AREA = "pat_area";
//    public static final String PATIENT_DISTRICT = "pat_district";
//    public static final String PATIENT_STATE = "pat_state";
//    public static final String PATIENT_COUNTRY = "pat_country";
//    public static final String PATIENT_STAFF_COMM = "pat_staff_comm";
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ROLE_TABLE);
        db.execSQL(CREATE_PATIENT_TABLE);
//        db.execSQL(CREATE_TABLE_ADMIN);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ROLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT);
//        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADMIN);
        onCreate(db);
    }
}
