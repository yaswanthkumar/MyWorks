package com.vaibhavapps.patiententry;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DBManager  {
    private DatabaseHelper dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }
    public void insertToRole(String uname, String pass, String em, String mob, String gen, String empid, String regArea, String dist, String st, String c, String role) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.USER_NAME, uname);
        contentValues.put(DatabaseHelper.PASSWORD, pass);
        contentValues.put(DatabaseHelper.EMAIL_ID, em);
        contentValues.put(DatabaseHelper.MOB_NO, mob);
        contentValues.put(DatabaseHelper.GENDER, gen);
        contentValues.put(DatabaseHelper.EMP_ID, empid);
        contentValues.put(DatabaseHelper.AREA, regArea);
        contentValues.put(DatabaseHelper.DISTRICT, dist);
        contentValues.put(DatabaseHelper.STATE, st);
        contentValues.put(DatabaseHelper.COUNTRY, c);
        contentValues.put(DatabaseHelper.ROLE, role);
        database.insert(DatabaseHelper.TABLE_ROLE, null, contentValues);
    }
//    public void insertToPatient()
    public void insertToPatient(String patient_id, String pat_name, String pat_email, String pat_mob, String pat_age, String pat_prof, String pat_gender, String pat_area, String pat_dist, String pat_state, String pat_country, String pat_staff_com, String subm_by, String subm_by_em) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.PATIENT_ID, patient_id);
        contentValues.put(DatabaseHelper.PATIENT_NAME, pat_name);
        contentValues.put(DatabaseHelper.PATIENT_EMAIL_ID, pat_email);
        contentValues.put(DatabaseHelper.PATIENT_MOB_NO, pat_mob);
        contentValues.put(DatabaseHelper.PATIENT_AGE, pat_age);
        contentValues.put(DatabaseHelper.PATIENT_PROFESSION, pat_prof);
        contentValues.put(DatabaseHelper.PATIENT_GENDER, pat_gender);
        contentValues.put(DatabaseHelper.PATIENT_AREA, pat_area);
        contentValues.put(DatabaseHelper.PATIENT_DISTRICT, pat_dist);
        contentValues.put(DatabaseHelper.PATIENT_STATE, pat_state);
        contentValues.put(DatabaseHelper.PATIENT_COUNTRY, pat_country);
        contentValues.put(DatabaseHelper.PATIENT_STAFF_COMM, pat_staff_com);
        contentValues.put(DatabaseHelper.SUBMITTED_BY, subm_by);
        contentValues.put(DatabaseHelper.SUBMITTED_BY_EMAIL, subm_by_em);
        database.insert(DatabaseHelper.TABLE_PATIENT, null, contentValues);

    }
    public void delete(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String deleteQueries = "DELETE FROM " + DatabaseHelper.TABLE_ROLE;
        db.execSQL(deleteQueries);
        db.close();
    }
    public static boolean doesDatabaseExist(Context context, String dbName) {
        File dbFile = context.getDatabasePath(dbName);
        return dbFile.exists();
    }
//    public long count() {
//
//        return DatabaseUtils.queryNumEntries(database, DatabaseHelper.TABLE_ROLE);
//    }
//    public long getUsersCount() {
//        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        long count = DatabaseUtils.queryNumEntries(db, DatabaseHelper.TABLE_ROLE);
//        db.close();
//        return count;
//    }
//public int getUsersCount() {
//    String countQuery = "SELECT COUNT(dbHelper.ROW_ID) FROM dbHelper.TABLE_ROLE";
//    SQLiteDatabase db = dbHelper.getReadableDatabase();
//    Cursor cursor = db.rawQuery(countQuery, null);
//
//    cursor.close();
//// return count
//    return cursor.getCount();
//
//}

    public int getUsersCount() {
        String countQuery = "SELECT  * FROM " + dbHelper.TABLE_ROLE;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        // return count
        int i = cursor.getCount();
        cursor.close();
        return i;
    }

    public int getPatientCount() {
        String countQuery = "SELECT  * FROM " + dbHelper.TABLE_PATIENT;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        // return count
        int i = cursor.getCount();
        Log.d("pat_count", String.valueOf(i));
        cursor.close();
        return i;
    }

    public boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                dbHelper.ROW_ID
        };
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // selection criteria
        String selection = dbHelper.EMAIL_ID + " = ?" + " AND " + dbHelper.PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         */
        Cursor cursor = db.query(dbHelper.TABLE_ROLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public ArrayList<DataRegisterHelper> readAllItems(String email ) {
        ArrayList<DataRegisterHelper> items = new ArrayList<DataRegisterHelper>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        String[] cols = new String[]{DatabaseHelper.USER_NAME, DatabaseHelper.EMAIL_ID, DatabaseHelper.ROLE, DatabaseHelper.MOB_NO};

        String selection = DatabaseHelper.EMAIL_ID + " = ?";
        String[] selectionArgs = {email};

        Cursor cursor = db.query(DatabaseHelper.TABLE_ROLE, null, selection, selectionArgs, null, null,null);

        if (cursor != null ) {
            while (cursor.moveToNext()) {
                DataRegisterHelper item = new DataRegisterHelper();
                item.id = cursor.getString(0);
                item.role = cursor.getString(1);
                item.uname = cursor.getString(2);
                item.pass = cursor.getString(3);
                item.gender = cursor.getString(4);
                item.em = cursor.getString(5);
                item.mob = cursor.getString(6);
                item.emp_id = cursor.getString(7);
                item.regArea = cursor.getString(8);
                item.dist = cursor.getString(9);
                item.state = cursor.getString(10);
                item.country = cursor.getString(11);

                items.add(item);
            }
        }
        return items;
    }
    public ArrayList<DataRegisterHelper> ReadAllFromDb() {
        ArrayList<DataRegisterHelper> items = new ArrayList<DataRegisterHelper>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        String[] cols = new String[]{DatabaseHelper.USER_NAME, DatabaseHelper.EMAIL_ID, DatabaseHelper.ROLE, DatabaseHelper.MOB_NO};



        Cursor cursor = db.query(DatabaseHelper.TABLE_ROLE, null, null, null, null, null,null);

        if (cursor != null ) {
            while (cursor.moveToNext()) {
                DataRegisterHelper item = new DataRegisterHelper();
//                item.id = cursor.getString(0);
//                item.role = cursor.getString(1);
//                item.uname = cursor.getString(2);
//                item.pass = cursor.getString(3);
//                item.gender = cursor.getString(4);
//                item.em = cursor.getString(5);
//                item.mob = cursor.getString(6);
//                item.emp_id = cursor.getString(7);
//                item.regArea = cursor.getString(8);
//                item.dist = cursor.getString(9);
//                item.state = cursor.getString(10);
//                item.country = cursor.getString(11);

                items.add(item);
            }
        }
        return items;
    }
    public ArrayList<PatientRegisterHelper> readPatients(String email) {
        ArrayList<PatientRegisterHelper> items = new ArrayList<PatientRegisterHelper>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        String[] cols = new String[]{DatabaseHelper.USER_NAME, DatabaseHelper.EMAIL_ID, DatabaseHelper.ROLE, DatabaseHelper.MOB_NO};

        String selection = DatabaseHelper.SUBMITTED_BY_EMAIL + " = ?";
        String[] selectionArgs = {email};

        Cursor cursor = db.query(DatabaseHelper.TABLE_PATIENT, null, selection, selectionArgs, null, null,null);

        if (cursor != null ) {
            while (cursor.moveToNext()) {

                PatientRegisterHelper item = new PatientRegisterHelper();
                item.patient_id = cursor.getString(0);
                item.uname = cursor.getString(1);
                item.email_pat = cursor.getString(2);
                item.mob_pat = cursor.getString(3);
                item.age_pat = cursor.getString(4);
                item.profession_pat = cursor.getString(5);
                item.gender_pat = cursor.getString(6);
                item.dist = cursor.getString(7);
                item.state = cursor.getString(8);
                item.country = cursor.getString(9);
                item.comments = cursor.getString(10);
                item.submit_by = cursor.getString(11);
                item.submit_by_email = cursor.getString(12);
                items.add(item);
            }
            cursor.close();
        }
        return items;

    }

    public ArrayList<PatientRegisterHelper> readPatients() {
        ArrayList<PatientRegisterHelper> items = new ArrayList<PatientRegisterHelper>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        String[] cols = new String[]{DatabaseHelper.USER_NAME, DatabaseHelper.EMAIL_ID, DatabaseHelper.ROLE, DatabaseHelper.MOB_NO};


        Cursor cursor = db.query(DatabaseHelper.TABLE_PATIENT, null, null, null, null, null,null);

        if (cursor != null ) {
            while (cursor.moveToNext()) {

                PatientRegisterHelper item = new PatientRegisterHelper();
                    item.patient_id = cursor.getString(0);
                    item.uname = cursor.getString(1);
                    item.email_pat = cursor.getString(2);
                    item.mob_pat = cursor.getString(3);
                    item.age_pat = cursor.getString(4);
                    item.profession_pat = cursor.getString(5);
                    item.gender_pat = cursor.getString(6);
                    item.dist = cursor.getString(7);
                    item.state = cursor.getString(8);
                    item.country = cursor.getString(9);
                    item.comments = cursor.getString(10);
                    item.submit_by = cursor.getString(11);
                    item.submit_by_email = cursor.getString(12);
                items.add(item);
            }
            cursor.close();
        }
        return items;

    }
    public ArrayList<DataRegisterHelper> readAllItems() {
        ArrayList<DataRegisterHelper> items = new ArrayList<DataRegisterHelper>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
//        String[] cols = new String[]{DatabaseHelper.USER_NAME, DatabaseHelper.EMAIL_ID, DatabaseHelper.ROLE, DatabaseHelper.MOB_NO};


        Cursor cursor = db.query(DatabaseHelper.TABLE_ROLE, null, null, null, null, null,null);

        if (cursor != null ) {
            while (cursor.moveToNext()) {
                DataRegisterHelper item = new DataRegisterHelper();
                item.id = cursor.getString(0);
                item.role = cursor.getString(1);
                item.uname = cursor.getString(2);
                item.pass = cursor.getString(3);
                item.gender = cursor.getString(4);
                item.em = cursor.getString(5);
                item.mob = cursor.getString(6);
                item.emp_id = cursor.getString(7);
                item.regArea = cursor.getString(8);
                item.dist = cursor.getString(9);
                item.state = cursor.getString(10);
                item.country = cursor.getString(11);

                items.add(item);
            }
            cursor.close();
        }

        return items;
    }








}
