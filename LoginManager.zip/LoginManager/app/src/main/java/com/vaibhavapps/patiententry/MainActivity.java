package com.vaibhavapps.patiententry;

import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements LoginFragment.OnEmailSendListener {
    SharedPreferences sharPref;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            LoginFragment loginFragment = new LoginFragment();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.parentLayout, loginFragment, "Login fragment");
            ft.addToBackStack(null);
            ft.commit();
        }



    @Override
    public void sendEmail(String email, String name) {
        PatientDashboardFragment pdf = new PatientDashboardFragment();
        Bundle bundle = new Bundle();
        bundle.putString("email", email);
        bundle.putString("name", name);
        pdf.setArguments(bundle);
    }

//ShedFragment sf = new ShedFragment();
//        Bundle b = new Bundle();
//        b.putString("position", position);
//        sf.setArguments(b);
//        FragmentManager fragmentManager = getSupportFragmentManager();
//        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//        fragmentTransaction.replace(R.id.parentLayout, sf, "Shed Fragment");
//        fragmentTransaction.commit();
    public interface EmailValidator {
         }

    public static boolean EmailValidator(String email){
        Pattern pattern = Patterns.EMAIL_ADDRESS;
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean PasswordValidator(String password){
        final String PASSWORD_PATTERN = "^([a-zA-Z+]+[0-9+]+[&@!#+]+)$";
        Pattern pattern;
        pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public void SharedPreferenceData(String email) {
            sharPref = getSharedPreferences(email, MODE_PRIVATE);

    }

}
