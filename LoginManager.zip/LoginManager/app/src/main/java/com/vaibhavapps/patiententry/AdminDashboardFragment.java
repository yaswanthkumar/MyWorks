package com.vaibhavapps.patiententry;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class AdminDashboardFragment extends Fragment {
    Button btn_user, btn_patients;

    ArrayList<PatientRegisterHelper> pat_list;
    ArrayList<DataRegisterHelper> users_list;
    ListView listView;
    List<String> data_patient;
    List<String> data_user;
    StringBuilder builder = new StringBuilder();
    public AdminDashboardFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
//        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_admin_dashboard, container, false);

       btn_patients = (Button) view.findViewById(R.id.button_patients);
       btn_user = (Button) view.findViewById(R.id.button_users);
       listView = (ListView) view.findViewById(R.id.listView_data);

        btn_patients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData_patient();

                if (!data_patient.isEmpty()) {
                    ArrayAdapter<String> itemsAdapter =
                            new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data_patient);
                    listView.setAdapter(itemsAdapter);
                } else {
                    Toast.makeText(getContext(), "No patients added", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btn_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData_user();

                if (!data_user.isEmpty()) {
                    ArrayAdapter<String> itemsAdapter =
                            new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data_user);
                    listView.setAdapter(itemsAdapter);
                } else {
                    Toast.makeText(getContext(), "No users registered", Toast.LENGTH_SHORT).show();
                }
            }
        });




        return view;
    }

    public List<String> getData_patient() {
        pat_list = new ArrayList<PatientRegisterHelper>();
        data_patient = new ArrayList<>();
        DBManager dbManager;
        dbManager = new DBManager(getActivity());
        dbManager.open();
        pat_list = dbManager.readPatients();
//
        for (int i = 0; i < pat_list.size();i++) {
//                builder.append(data_list.get(i).role + data_list.get(i).uname + data_list.get(i).em + data_list.get(i).pass + data_list.get(i).mob + data_list.get(i).emp_id + data_list.get(i).regArea + data_list.get(i).dist + data_list.get(i).state + data_list.get(i).country);
            builder.append(pat_list.get(i).patient_id + "\n"
                    + pat_list.get(i).uname + "\n"
                    + pat_list.get(i).email_pat + "\n"
                    + pat_list.get(i).mob_pat + "\n"
                    + pat_list.get(i).comments + "\n"
                    + pat_list.get(i).age_pat + "\n"
                    + pat_list.get(i).gender_pat + "\n"
                    + pat_list.get(i).profession_pat + "\n"
                    + pat_list.get(i).regArea + "\n"
                    + pat_list.get(i).dist + "\n"
                    + pat_list.get(i).state + "\n"
                    + pat_list.get(i).country + "\n"
            );
            data_patient.add(pat_list.get(i).patient_id + "\n"
                    + pat_list.get(i).uname + "\n"
                    + pat_list.get(i).email_pat + "\n"
                    + pat_list.get(i).mob_pat + "\n"
                    + pat_list.get(i).comments + "\n"
                    + pat_list.get(i).age_pat + "\n"
                    + pat_list.get(i).gender_pat + "\n"
                    + pat_list.get(i).profession_pat + "\n"
                    + pat_list.get(i).regArea + "\n"
                    + pat_list.get(i).dist + "\n"
                    + pat_list.get(i).state + "\n"
                    + pat_list.get(i).country + "\n"
            );


        }
        dbManager.close();
        return data_patient;
    }

    public List<String> getData_user() {
        users_list = new ArrayList<DataRegisterHelper>();
        data_user = new ArrayList<String>();
        DBManager dbManager;
        dbManager = new DBManager(getActivity());
        dbManager.open();
        users_list = dbManager.readAllItems();
//
        for (int i = 0; i < users_list.size();i++) {
//                builder.append(data_list.get(i).role + data_list.get(i).uname + data_list.get(i).em + data_list.get(i).pass + data_list.get(i).mob + data_list.get(i).emp_id + data_list.get(i).regArea + data_list.get(i).dist + data_list.get(i).state + data_list.get(i).country);
            builder.append(users_list.get(i).uname + "\n"
                    + users_list.get(i).emp_id + "\n"
                    + users_list.get(i).pass + "\n"
                    + users_list.get(i).em + "\n"
                    + users_list.get(i).mob + "\n"
                    + users_list.get(i).gender + "\n"

                    + users_list.get(i).regArea + "\n"
                    + users_list.get(i).dist + "\n"
                    + users_list.get(i).state + "\n"
                    + users_list.get(i).country + "\n"

            );
            data_user.add(users_list.get(i).uname + "\n"
                    + users_list.get(i).emp_id + "\n"
                    + users_list.get(i).pass + "\n"
                    + users_list.get(i).em + "\n"
                    + users_list.get(i).mob + "\n"
                    + users_list.get(i).gender + "\n"

                    + users_list.get(i).regArea + "\n"
                    + users_list.get(i).dist + "\n"
                    + users_list.get(i).state + "\n"
                    + users_list.get(i).country + "\n"

            );


        }
        dbManager.close();
        return data_user;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
//        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
