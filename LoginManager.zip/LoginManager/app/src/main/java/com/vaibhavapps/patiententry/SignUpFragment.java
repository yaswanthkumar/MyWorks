package com.vaibhavapps.patiententry;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SignUpFragment extends Fragment {
    EditText uName, password, emp_id, email_Id, mob_no;
    Spinner reg_area, dist, state, country;
    Spinner spn_reg_type;
    List<String> list;
    RadioGroup Gender;
    Button btn_signUp;
    RadioButton g_m, g_f;
    String gen;
    String empid_init = "ODEBB2018001";
    DBManager dbManager;
    SQLiteDatabase database;
    Button btn_choosePic;

    public SignUpFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v = inflater.inflate(R.layout.fragment_sign_up, container, false);

        uName = (EditText) v.findViewById(R.id.et_signUp_uName);
        password = (EditText) v.findViewById(R.id.et_signUp_Password);
        emp_id = (EditText) v.findViewById(R.id.et_employeeId);
        reg_area = (Spinner) v.findViewById(R.id.spn_reg_Area);
        btn_choosePic = (Button) v.findViewById(R.id.button_insertImage);
        email_Id = (EditText) v.findViewById(R.id.et_reg_email);
        mob_no = (EditText) v.findViewById(R.id.et_reg_mobile);
        Gender = v.findViewById(R.id.rg_gender);
        g_m = (RadioButton) v.findViewById(R.id.rb_male);
        g_f = (RadioButton) v.findViewById(R.id.rb_female);
        btn_signUp = (Button) v.findViewById(R.id.signUp_button);





//        Spinner for role of employee.
        spn_reg_type = (Spinner) v.findViewById(R.id.spinner_reg_type);
        list = new ArrayList<>();
        list.add("User");
        list.add("Admin");

        ArrayAdapter<String> aap_role = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        spn_reg_type.setAdapter(aap_role);

//        String empid_init = "ODEBB2018001";
//    String partOne = empid_init.substring(0, 5); //split after a sequence of 5 letters
//        Log.v("partone",partOne);
//    String  partTwo = empid_init.substring(5, empid_init.length());
//        Log.v("partTwo",partTwo);

        if(DBManager.doesDatabaseExist(getContext(),DatabaseHelper.DB_NAME)) {
            Log.v("database", "data");

            String partOne = empid_init.substring(0, 5); //split after a sequence of 5 letters
            Log.v("partone",partOne);
            String  partTwo = empid_init.substring(5, empid_init.length());
            Log.v("partTwo",partTwo);
            DBManager dbManager;
            dbManager = new DBManager(getActivity());
            dbManager.open();

            int count = dbManager.getUsersCount();
            int result = Integer.parseInt(partTwo) + count;
            partTwo = partOne + String.valueOf(result);
            emp_id.setText(partTwo);
        }
         else {
            emp_id.setText("ODEBB2018001");
            Log.v("database", "else part");

        }





//
//    emp_id.setText(partOne + result);
//        Spinner creation for regional area.
        reg_area = (Spinner) v.findViewById(R.id.spn_reg_Area);
        list = new ArrayList<>();
        list.add("Agara");
        list.add("Anand Rao Circle");
        list.add("Attibele");
        list.add("Banaswadi");
        list.add("Begur");
        list.add("Bellandur");
        list.add("Bommanahalli ");
        list.add("Bommasandra");
        list.add("BTM layout");
        list.add("Chandapura");
        list.add("Chikkaballapura");
        list.add("Dairy circle");
        list.add("Dasarahalli");
        list.add("Devanahalli");
        list.add("Doddakannelli");
        list.add("Domlur");
        list.add("HAL");
        list.add("Indira Nagar");
        list.add("Marathahalli");
        list.add("Whitefield");

        ArrayAdapter<String> aap_regArea = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        reg_area.setAdapter(aap_regArea);

//spinner for district.
        dist = (Spinner) v.findViewById(R.id.spn_signUp_dist);
        list = new ArrayList<>();
        list.add("Bengaluru");
        ArrayAdapter<String> aap_dist = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        dist.setAdapter(aap_dist);
//       Spinner for state
        state = (Spinner) v.findViewById(R.id.spn_signUp_state);
                list = new ArrayList<>();
                list.add("Karnataka");
                ArrayAdapter<String> aap_state = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
                state.setAdapter(aap_state);

//        Spinner for the Country.
        country = (Spinner) v.findViewById(R.id.spn_signUp_country);
        list = new ArrayList<>();
        list.add("India");
        ArrayAdapter<String> aap_country = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        country.setAdapter(aap_country);

        // Gender selection
        int g_select = Gender.getCheckedRadioButtonId();
        switch (g_select) {
            case R.id.rb_male:
                gen = "M";
                break;
            case R.id.rb_female:
                gen = "F";
                break;
            default:
                break;
        }


        btn_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!uName.getText().toString().isEmpty() && !password.getText().toString().isEmpty() && !gen.isEmpty() && !email_Id.getText().toString().isEmpty() && !mob_no.getText().toString().isEmpty()) {

                    String uname = uName.getText().toString();
                    String pass = password.getText().toString();
                    String gender = gen.trim();
                    String em = email_Id.getText().toString();
                    String mob = mob_no.getText().toString();
                    String empId = emp_id.getText().toString();
                    String regArea = reg_area.getSelectedItem().toString();
                    String district = dist.getSelectedItem().toString();
                    String st = state.getSelectedItem().toString();
                    String c = country.getSelectedItem().toString();
                    String role = spn_reg_type.getSelectedItem().toString();

                    Log.d("user_name", uname);
                    Log.d("pass", pass);
                    Log.d("email", em);
                    Log.d("mobile", mob);
                    Log.d("gender", gender);
                    Log.d("empId", empId);
                    Log.d("area", regArea);
                    Log.d("district", district);
                    Log.d("state", st);
                    Log.d("country", c);
                    Log.d("role", role);

                    DBManager dbManager;
                    dbManager = new DBManager(getActivity());
                    dbManager.open();
                    dbManager.insertToRole(uname, pass, em, mob, gender, empId, regArea, district, st, c, role);
                    Toast.makeText(getContext(), "employee created successfully", Toast.LENGTH_SHORT).show();
                    dbManager.close();
                    LoginFragment loginFragment = new LoginFragment();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.parentLayout, loginFragment, "login fragment");
                    ft.addToBackStack(null);
                    ft.commit();
                } else {
                    Toast.makeText(getContext(), "entry not saved", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return v;
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
