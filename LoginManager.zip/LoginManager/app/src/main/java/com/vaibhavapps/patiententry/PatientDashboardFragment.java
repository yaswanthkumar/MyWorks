package com.vaibhavapps.patiententry;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;


public class PatientDashboardFragment extends Fragment {
    EditText et_patient_id, et_patient_name, et_patient_email, et_patient_age, et_patient_prof, et_patient_mobile;
    RadioGroup rg_patient_gender;
    RadioButton rb_patient_m, rb_patient_f;
    Spinner reg_area, dist, state, country;
    List<String> list;
    String gen;
    Button btn_submit;
    EditText et_staffComment;
    SharedPreferences preferences;
    public static final String PREFS_PAT_ID = "pref_id";
    String pat_id_init = "PAT001";
    DBManager dbManager;

    public static final String PREFS_NAME = "Store_Data";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_patient_dashboard, container, false);

        et_patient_name = (EditText) view.findViewById(R.id.et_patient_name);
        et_patient_id = (EditText) view.findViewById(R.id.et_patient_id);
        et_patient_email = (EditText) view.findViewById(R.id.et_patient_email);
        et_patient_age = (EditText) view.findViewById(R.id.et_patient_age);
        et_patient_prof = (EditText) view.findViewById(R.id.et_patient_profession);
        et_staffComment= (EditText) view.findViewById(R.id.editText_comment);

        rg_patient_gender = (RadioGroup) view.findViewById(R.id.radioGroup_gender_patient);
        rb_patient_m = (RadioButton) view.findViewById(R.id.radioButton_male);
        rb_patient_f = (RadioButton) view.findViewById(R.id.radioButton_female);
        reg_area = (Spinner) view.findViewById(R.id.spinner_patient_regArea);
        btn_submit = (Button) view.findViewById(R.id.button_submit);
        et_patient_mobile = (EditText) view.findViewById(R.id.et_patient_mobile);

        preferences = this.getActivity().getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

////        Creating preference
////        Set the patient id.
//        String value = preferences.getString("pat_id", "");
//        et_patient_id.setText(value);

        dbManager = new DBManager(getActivity());
        dbManager.open();
        int c = dbManager.getPatientCount();

        Log.d("c", String.valueOf(c));
        if ( c > 0)
        {
            String pat_id_rec = preferences.getString("pat_id", "");

            String partOne = pat_id_init.substring(0, 3); //split after a sequence of 5 letters
            Log.v("pat_partone",partOne);
            String  partTwo = pat_id_init.substring(3, pat_id_init.length());
            Log.v("pat_partTwo",partTwo);



            int count = dbManager.getPatientCount();
            Log.d("count", String.valueOf(count));
            int result = Integer.parseInt(partTwo) + count;
            partTwo = partOne + String.valueOf(result);
            et_patient_id.setText(partTwo);

            dbManager.close();
        }
        else
        {
            et_patient_id.setText(pat_id_init);
        }
//        Spinner creation for regional area.
        reg_area = (Spinner) view.findViewById(R.id.spinner_patient_regArea);
        list = new ArrayList<>();
        list.add("Agara");
        list.add("Anand Rao Circle");
        list.add("Attibele");
        list.add("Banaswadi");
        list.add("Begur");
        list.add("Bellandur");
        list.add("Bommanahalli ");
        list.add("Bommasandra");
        list.add("BTM layout");
        list.add("Chandapura");
        list.add("Chikkaballapura");
        list.add("Dairy circle");
        list.add("Dasarahalli");
        list.add("Devanahalli");
        list.add("Doddakannelli");
        list.add("Domlur");
        list.add("HAL");
        list.add("Indira Nagar");
        list.add("Marathahalli");
        list.add("Whitefield");

        ArrayAdapter<String> aap_regArea = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        reg_area.setAdapter(aap_regArea);

// spinner for district.
        dist = (Spinner) view.findViewById(R.id.spinner_patient_dist);
        list = new ArrayList<>();
        list.add("Bengaluru");
        ArrayAdapter<String> aap_dist = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        dist.setAdapter(aap_dist);
//       Spinner for state
        state = (Spinner) view.findViewById(R.id.spinner_patient_state);
        list = new ArrayList<>();
        list.add("Karnataka");
        ArrayAdapter<String> aap_state = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        state.setAdapter(aap_state);

//        Spinner for the Country.
        country = (Spinner) view.findViewById(R.id.spinner_patient_country);
        list = new ArrayList<>();
        list.add("India");
        ArrayAdapter<String> aap_country = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, list);
        country.setAdapter(aap_country);

        // Gender selection
        int g_select = rg_patient_gender.getCheckedRadioButtonId();
        switch (g_select) {
            case R.id.radioButton_male:
                gen = "M";
                break;
            case R.id.radioButton_female:
                gen = "F";
                break;
            default:
                break;

        }

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String pat_id = et_patient_id.getText().toString();
              String pat_name = et_patient_name.getText().toString();
              String pat_email = et_patient_email.getText().toString();
              String pat_gen = gen.trim();
              String pat_prof = et_patient_prof.getText().toString();
              String pat_age = et_patient_age.getText().toString();
              String pat_area = reg_area.getSelectedItem().toString();
              String pat_dist = dist.getSelectedItem().toString();
              String pat_state = state.getSelectedItem().toString();
              String pat_country = country.getSelectedItem().toString();

              String pat_mob = et_patient_mobile.getText().toString();
              String pat_staffCom = et_staffComment.getText().toString();

                String name_receive = preferences.getString("user_name", null);
                String email_receive = preferences.getString("user_email",null);
                DBManager dbManager;
                dbManager = new DBManager(getActivity());
                dbManager.open();

                    dbManager.insertToPatient(pat_id, pat_name, pat_email, pat_mob, pat_age, pat_prof, pat_gen, pat_area, pat_dist, pat_state, pat_country, pat_staffCom, name_receive, email_receive);
                Toast.makeText(getContext(), "Patient added successfully", Toast.LENGTH_LONG).show();
                Log.d("22", "inserted");
                dbManager.close();
//                Log.v("email_receive", email_receive);
                    //    public void insertToPatient(String pat_id, String pat_name, String pat_email, String pat_mob, String pat_gender, String pat_area, String pat_dist,
// String pat_state, String pat_country, String pat_staff_com, String subm_by) {
            }
        });
        return view;

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


}