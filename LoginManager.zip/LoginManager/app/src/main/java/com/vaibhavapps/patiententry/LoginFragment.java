package com.vaibhavapps.patiententry;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class LoginFragment extends Fragment {

    TextView new_user;
    EditText email_id;
    EditText pass;
    Button login_btn, cancel_btn;
    String role;
    String role_admin = "admin";
    String role_user = "user";
    String user_dbname, user_email;
    DBManager dbManager;
    Cursor cursor;
    List<DataRegisterHelper> items;
    SQLiteDatabase db;
    DatabaseHelper databaseHelper;
    SharedPreferences preferences;

    public static final String PREFS_NAME = "Store_Data";

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_login, container, false);
        new_user = (TextView) v.findViewById(R.id.tv_new_user);
        email_id = (EditText) v.findViewById(R.id.editText_login_email);
        pass = (EditText) v.findViewById(R.id.editText_login_pass);
        login_btn = (Button) v.findViewById(R.id.button_login);
        cancel_btn = (Button) v.findViewById(R.id.button_cancel);
        preferences = this.getActivity().getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        new_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("flow starts here", "Vaibhav");
                SignUpFragment signUpFragment = new SignUpFragment();
                Log.v("flow starts here", "Vaibhav");
                FragmentManager fm = getFragmentManager();
                Log.v("flow starts here", "Vaibhav");
                FragmentTransaction ft = fm.beginTransaction();
                Log.v("flow starts here", "Vaibhav");
                ft.replace(R.id.parentLayout, signUpFragment, "SignUp fragment");
                Log.v("flow starts here", "Vaibhav");
                ft.commit();
                Log.v("flow starts here", "Vaibhav");
            }
        });


//


        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String em = email_id.getText().toString();
                String pswd = pass.getText().toString();


                DBManager dbManager;
                dbManager = new DBManager(getActivity());
                dbManager.open();
                Boolean availability = dbManager.checkUser(em, pswd);
                if (availability) {
                    ArrayList<DataRegisterHelper> list = dbManager.readAllItems(em);
                    for (int i = 0; i < list.size(); i++) {
                        role = list.get(i).getRole();
                        user_dbname = list.get(i).getUname();
                        user_email = list.get(i).getEm();
//                         sendListener.sendEmail(user_email, user_dbname);


                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("user_email", user_email);
                        editor.putString("user_name", user_dbname);
                        editor.apply();


                    }
                    if (role.equalsIgnoreCase(role_admin)) {
                        AdminDashboardFragment adminDashboardFragment = new AdminDashboardFragment();
                        Log.d("111", "test");
                        FragmentManager fragmentManager = getFragmentManager();
                        Log.d("111", "test");
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        Log.d("111", "test");
                        fragmentTransaction.replace(R.id.parentLayout, adminDashboardFragment, "Admin Dashboard fragment");
                        Log.d("111", "test");
                        fragmentTransaction.addToBackStack(null);
                        Log.d("111", "test");


                        fragmentTransaction.commit();
                        Log.d("111", "test");
                        Toast.makeText(getContext(), " Admin Successfully login", Toast.LENGTH_LONG).show();
                        Log.d("111", "test");
                    }
                    if (role.equalsIgnoreCase(role_user)) {

                        UserDashboardFragment userDashboardFragment = new UserDashboardFragment();
                        Bundle args = new Bundle();
                        args.putString("email_login", em);
                        userDashboardFragment.setArguments(args);
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.parentLayout, userDashboardFragment, "Data fragment");
                        ft.addToBackStack(null);
                        ft.commit();

                        Toast.makeText(getContext(), " User Successfully login", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getContext(), " Please enter correct details", Toast.LENGTH_SHORT).show();
                }
            }
        });
        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email_id.setText("");
                 pass.setText("");
            }
        });

        return v;
    }
//
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//         Activity activity = (Activity) context;
//        try {
////            em_listener = (LoginFragment.EmailSendListener) context;
//        } catch (ClassCastException e) {
//            throw new ClassCastException(activity.toString() + "must implement EmailSendListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
//        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface SendDataFromDb {
        // TODO: Update argument type and name
        void sendData(ArrayList list);
    }
    OnEmailSendListener sendListener;
    interface OnEmailSendListener {
        // TODO: Update argument type and name
        void sendEmail(String email, String name);
    }
}
