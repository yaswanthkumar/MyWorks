package com.vaibhavapps.patiententry;

public class DataRegisterHelper {

    //    String uname, String pass, String em, String mob,
// String gen, String empid, String regArea, String dist, String st, String c
    String id;
    String uname;
    String pass;
    String em;
    String mob;
    String gender;
    String emp_id;
    String regArea;
    String dist;
    String state;


    String role;
    String country;
    // Empty constructor
    public DataRegisterHelper() {
    }
//   constructor


    public DataRegisterHelper(String id, String uname, String pass, String em, String mob, String gender, String emp_id, String regArea, String dist, String state, String country, String role) {
        this.id = id;
        this.uname = uname;
        this.pass = pass;
        this.em = em;
        this.mob = mob;
        this.gender = gender;
        this.emp_id = emp_id;
        this.regArea = regArea;
        this.dist = dist;
        this.state = state;
        this.country = country;
        this.role = role;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getEm() {
        return em;
    }

    public void setEm(String em) {
        this.em = em;
    }

    public String getMob() {
        return mob;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(String emp_id) {
        this.emp_id = emp_id;
    }

    public String getRegArea() {
        return regArea;
    }

    public void setRegArea(String regArea) {
        this.regArea = regArea;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(String dist) {
        this.dist = dist;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    public String getRole() {
        
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}
