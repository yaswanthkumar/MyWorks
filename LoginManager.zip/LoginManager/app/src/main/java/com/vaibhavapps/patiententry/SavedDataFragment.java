package com.vaibhavapps.patiententry;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.List;


public class SavedDataFragment extends Fragment {
    String email_login;
    ArrayList<PatientRegisterHelper> pat_list;
    ListView listView_pat;
    List<String> data;

    public SavedDataFragment() {
        // Required empty public constructor
    }


//
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            email_login = getArguments().getString("email_login");
            Log.d("email", email_login);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_saved_data, container, false);
        listView_pat = (ListView) view.findViewById(R.id.patientList);
        getPatientData();

        ArrayAdapter<String> itemsAdapter =
                new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data);
        listView_pat.setAdapter(itemsAdapter);
        return view;
    }

    public List<String> getPatientData() {
        pat_list = new ArrayList<PatientRegisterHelper>();
        data = new ArrayList<>();
        DBManager dbManager;
        dbManager = new DBManager(getActivity());
        dbManager.open();
        pat_list = dbManager.readPatients(email_login);
//
        for (int i = 0; i < pat_list.size();i++) {
//                builder.append(data_list.get(i).role + data_list.get(i).uname + data_list.get(i).em + data_list.get(i).pass + data_list.get(i).mob + data_list.get(i).emp_id + data_list.get(i).regArea + data_list.get(i).dist + data_list.get(i).state + data_list.get(i).country);


//            data.add(pat_list.get(i).patient_id + "\n"
//                    + pat_list.get(i).uname + "\n"
//                    + pat_list.get(i).email_pat + "\n"
//                    + pat_list.get(i).mob_pat + "\n"
//                    + pat_list.get(i).comments + "\n"
//                    + pat_list.get(i).age_pat + "\n"
//                    + pat_list.get(i).gender_pat + "\n"
//
//

            data.add(pat_list.get(i).patient_id + "\n"
                    + pat_list.get(i).uname + "\n"
                    + pat_list.get(i).email_pat + "\n"
                    + pat_list.get(i).mob_pat + "\n"
                    + pat_list.get(i).comments + "\n"
                    + pat_list.get(i).gender_pat + "\n"
                    + pat_list.get(i).profession_pat + "\n"
                    + pat_list.get(i).regArea + "\n"
                    + pat_list.get(i).dist + "\n"
                    + pat_list.get(i).state + "\n"
                    + pat_list.get(i).country + "\n"
                    + pat_list.get(i).submit_by + "\n"
                    + pat_list.get(i).submit_by_email + "\n");
        }

        return data;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
//        mListener = null;
    }


}

