package com.vaibhavapps.patiententry;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;




public class UserDashboardFragment extends Fragment {
    ImageView iv_addPatient;
    Button btn_patient_list;
    String email_login;
    public UserDashboardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            email_login = getArguments().getString("email_login");
            Log.d("email", email_login);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_dashboard, container, false);
        iv_addPatient = (ImageView) view.findViewById(R.id.imageView_addPatient);
        btn_patient_list = (Button) view.findViewById(R.id.btn_patientList);
        iv_addPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PatientDashboardFragment patientDashboardFragment = new PatientDashboardFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.parentLayout, patientDashboardFragment, "patient dashboard fragment");
                ft.addToBackStack(null);
                ft.commit();
            }
        });
        btn_patient_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SavedDataFragment sdf = new SavedDataFragment();
                Bundle args = new Bundle();
                args.putString("email_login", email_login);
                sdf.setArguments(args);
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.parentLayout, sdf, "patient list");
                ft.addToBackStack(null);
                ft.commit();
            }
        });


//        textViewWelcome.setText();

        return view;
    }



}
