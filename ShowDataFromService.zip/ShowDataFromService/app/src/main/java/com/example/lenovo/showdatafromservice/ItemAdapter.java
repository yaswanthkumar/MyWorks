package com.example.lenovo.showdatafromservice;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lenovo.showdatafromservice.model.Item;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private List<Item.Row> items;
    private Context context;

    public ItemAdapter(Context applicationcontext, List<Item.Row> itemArrayList) {

        this.context = applicationcontext;
        this.items = itemArrayList;
    }


    public ItemAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_user, viewGroup, false);

        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull ItemAdapter.ViewHolder holder, int i) {
        holder.usertitle.setText(items.get(i).getTitle());
        holder.disc.setText(items.get(i).getDescription());
        Glide.with(context)
                .load(items.get(i).getImageHref()).placeholder(R.drawable.load).into(holder.imageView);
    }

    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        private TextView usertitle,disc;
        private ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            usertitle =(TextView)itemView.findViewById(R.id.user_titles);
            disc =(TextView)itemView.findViewById(R.id.discription);
            imageView=(ImageView)itemView.findViewById(R.id.cover);


        }

    }

}
