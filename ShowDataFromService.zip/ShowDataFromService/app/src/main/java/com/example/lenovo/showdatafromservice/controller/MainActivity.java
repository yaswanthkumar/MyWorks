package com.example.lenovo.showdatafromservice.controller;

import android.app.ProgressDialog;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.showdatafromservice.ItemAdapter;
import com.example.lenovo.showdatafromservice.R;
import com.example.lenovo.showdatafromservice.api.Client;
import com.example.lenovo.showdatafromservice.api.Service;
import com.example.lenovo.showdatafromservice.model.Item;
import com.example.lenovo.showdatafromservice.model.ItemResponse;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rcv;
    TextView disconnect;
    private Item item;
    ProgressDialog pd;
    private SwipeRefreshLayout srl;
    String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        srl = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        disconnect = (TextView) findViewById(R.id.internet_disconnected);
        srl.setColorSchemeResources(android.R.color.holo_orange_dark);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadJSON();
                Toast.makeText(MainActivity.this, "page is refreshing  ", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void initView() {
        pd = new ProgressDialog(this);
        pd.setMessage("please wait");
        pd.setCancelable(false);
        pd.show();
        rcv = (RecyclerView) findViewById(R.id.recycleview);
        rcv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rcv.smoothScrollToPosition(0);
        loadJSON();
    }

    private void loadJSON() {
        disconnect = (TextView) findViewById(R.id.internet_disconnected);
        try {

            Client Client = new Client();
            Service api = Client.getClient().create(Service.class);


            Call<ItemResponse> call = api.getRows();

            call.enqueue(new Callback<ItemResponse>() {
                             @Override
                             public void onResponse(Call<ItemResponse> call, Response<ItemResponse> response) {

                                 List<Item.Row> items = response.body().getRows();
                                 title = response.body().getTitle();
                                 android.support.v7.app.ActionBar ab = getSupportActionBar();
                                 ab.setTitle(title);
                                 rcv.setAdapter(new ItemAdapter(getApplicationContext(), items));
                                 rcv.smoothScrollToPosition(0);
                                 srl.setRefreshing(false);
                                 pd.hide();
                             }

                             @Override
                             public void onFailure(Call<ItemResponse> call, Throwable t) {
                                 Log.d("ERROR IS", t.getMessage());
                                 disconnect.setVisibility(View.VISIBLE);
                                 pd.hide();
                                 Toast.makeText(MainActivity.this, "Failure while fetching data " + t.getMessage(), Toast.LENGTH_SHORT).show();
                             }
                         }
            );


        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Exception in loadJSON method", Toast.LENGTH_SHORT).show();

        }
    }


}
