package com.vaibhavapps.retrofitdemo.activity;

import android.app.ProgressDialog;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.vaibhavapps.retrofitdemo.Model.Item;
import com.vaibhavapps.retrofitdemo.R;
import com.vaibhavapps.retrofitdemo.adapter.ItemAdapter;
import com.vaibhavapps.retrofitdemo.network.Client;
import com.vaibhavapps.retrofitdemo.network.Service;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rcv;
    TextView disconnect;
    private Item item;
    ProgressDialog pd;
    private SwipeRefreshLayout srl;
    List<Item> list = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();

        srl = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        disconnect = (TextView) findViewById(R.id.internet_disconnected);
        srl.setColorSchemeResources(android.R.color.holo_blue_bright);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadJSON();
                Toast.makeText(MainActivity.this, "page is refreshing  ", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void initView() {
        pd = new ProgressDialog(this);
        pd.setMessage("please wait");
        pd.setCancelable(false);
        pd.show();
        rcv = (RecyclerView) findViewById(R.id.recyclerView);
        rcv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rcv.smoothScrollToPosition(0);
        loadJSON();
    }

    private void loadJSON() {
        try {
            Client Client = new Client();
            Service service = Client.getClient().create(Service.class);
            Log.d("json", "loading json");
            Call<List<Item>> call = service.getUserTodo();

            call.enqueue(new Callback<List<Item>>() {
                @Override
                public void onResponse(Call<List<Item>> call, Response<List<Item>> response) {
                    list = response.body();
                    rcv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

                    ItemAdapter itemAdapter = new ItemAdapter(getApplicationContext(), list);

                    rcv.setAdapter(itemAdapter);
                    pd.hide();
                }
//recyclerView = findViewById(R.id.recycler_view);
//LinearLayoutManager manager = new LinearLayoutManager(this);
//recyclerView.setLayoutManager(manager);
//recyclerView.setHasFixedSize(true);
//adapter = new MyAdapter();
//recyclerView.setAdapter(adapter);
                @Override
                public void onFailure(Call<List<Item>> call, Throwable t) {
                    Log.d("Error is", t.getMessage());
                    disconnect.setVisibility(View.VISIBLE);
                    pd.hide();
                    Toast.makeText(MainActivity.this, "Failure while fetching data " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e){
           e.printStackTrace();
           Toast.makeText(MainActivity.this, "Exception in loadJSON", Toast.LENGTH_SHORT).show();
        }
    }



}
