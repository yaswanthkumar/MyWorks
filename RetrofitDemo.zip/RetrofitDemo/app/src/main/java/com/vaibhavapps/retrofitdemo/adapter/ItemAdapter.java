package com.vaibhavapps.retrofitdemo.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.vaibhavapps.retrofitdemo.Model.Item;
import com.vaibhavapps.retrofitdemo.R;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private List<Item> item;
    Context context ;
    public ItemAdapter(Context context, List<Item> item) {

    this.item = item ;
    this.context = context;
    }

    @NonNull
    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(context).inflate(R.layout.rowitem, null);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemAdapter.ViewHolder holder, int position) {
        Log.d("uid", item.get(position).getTitle() );
        holder.title.setText(item.get(position).getTitle());

       Log.d("uid", item.get(position).getUserId().toString() );

        holder.userId.setText(String.valueOf(item.get(position).getUserId()));

        Log.d("uid", item.get(position).getId().toString() );
        holder.listId.setText(String.valueOf(item.get(position).getId()));
//        rollNo.setText(Integer.toString(items[position].getRollNo()));


        Log.d("uidt", item.get(position).getCompleted().toString() );
        holder.completed.setText(String.valueOf(item.get(position).getCompleted().toString()));
    }

    @Override
    public int getItemCount() {
        Log.d("count", "getItemCount");
        return item.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        private TextView userId, listId, title, completed;
//        private ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            userId =(TextView)itemView.findViewById(R.id.textView_userId);
            listId =(TextView)itemView.findViewById(R.id.textView_ListId);
            title = (TextView)itemView.findViewById(R.id.textView_title);
            completed = (TextView)itemView.findViewById(R.id.textView_complete);

        }

    }
}
